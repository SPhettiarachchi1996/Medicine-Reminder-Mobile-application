/** Automatically generated file. DO NOT MODIFY */
package com.example.medicinereminder.test;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}