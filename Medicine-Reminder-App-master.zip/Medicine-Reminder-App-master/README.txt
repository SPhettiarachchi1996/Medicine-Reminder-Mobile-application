MedCheck Application
Developed in CIS350 - Software Development

TODO:
Pillcam
Calendar
Take Pill Page Flow
Field Validation

Backend??
